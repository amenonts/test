
# State Enum

Status of user account. acitve or inactive.

## Enumeration

`StateEnum`

## Fields

| Name |
|  --- |
| `ACTIVE` |
| `IN_ACTIVE` |

