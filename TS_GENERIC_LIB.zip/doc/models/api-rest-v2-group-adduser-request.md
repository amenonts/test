
# Api Rest V2 Group Adduser Request

## Structure

`ApiRestV2GroupAdduserRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string \| undefined` | Optional | Name of the group |
| `id` | `string \| undefined` | Optional | The GUID of the group |
| `users` | `string[] \| undefined` | Optional | A JSON array of name of users |

## Example (as JSON)

```json
{
  "name": null,
  "id": null,
  "users": null
}
```

