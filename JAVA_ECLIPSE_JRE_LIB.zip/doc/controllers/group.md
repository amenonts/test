# Group

```java
GroupController groupController = client.getGroupController();
```

## Class Name

`GroupController`

## Methods

* [Get Group](/doc/controllers/group.md#get-group)
* [Add Users to Group](/doc/controllers/group.md#add-users-to-group)


# Get Group

To get the details of a specific group by name or id, use this endpoint. At Least one value needed.  When both are given id will be considered to fetch user information.

```java
CompletableFuture<GroupResponse> getGroupAsync(
    final String name,
    final String id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Query, Optional | Name of the group |
| `id` | `String` | Query, Optional | The GUID of the group to query |

## Response Type

[`GroupResponse`](/doc/models/group-response.md)

## Example Usage

```java
groupController.getGroupAsync(null, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Operation failed or unautherized request | [`ErrorResponseException`](/doc/models/error-response-exception.md) |


# Add Users to Group

To programmatically add existing ThoughtSpot users to a group use API endpoint. When you assign users to a group, the users inherits the privileges assigned to that group. At least one of id or name of group is required. When both are given user id will be considered.

```java
CompletableFuture<Boolean> addUsersToGroupAsync(
    final ApiRestV2GroupAdduserRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ApiRestV2GroupAdduserRequest`](/doc/models/api-rest-v2-group-adduser-request.md) | Body, Optional | - |

## Response Type

`boolean`

## Example Usage

```java
groupController.addUsersToGroupAsync(null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Operation failed or unautherized request | [`ErrorResponseException`](/doc/models/error-response-exception.md) |

