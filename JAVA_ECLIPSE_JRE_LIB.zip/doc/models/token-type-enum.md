
# Token Type Enum

Type of token to be generated

## Enumeration

`TokenTypeEnum`

## Fields

| Name |
|  --- |
| `Cookie` |
| `Bearer` |

