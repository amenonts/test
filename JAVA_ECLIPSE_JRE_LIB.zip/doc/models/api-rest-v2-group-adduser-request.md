
# Api Rest V2 Group Adduser Request

## Structure

`ApiRestV2GroupAdduserRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Optional | Name of the group | String getName() | setName(String name) |
| `Id` | `String` | Optional | The GUID of the group | String getId() | setId(String id) |
| `Users` | `List<String>` | Optional | A JSON array of name of users | List<String> getUsers() | setUsers(List<String> users) |

## Example (as JSON)

```json
{
  "name": null,
  "id": null,
  "users": null
}
```

